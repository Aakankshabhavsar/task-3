
import './App.css';
import TodoList from './components/TodoList';

function App() {
  return (
    <div className="Todo-list-container">
     <TodoList></TodoList> 
    </div>
  );
}

export default App;
